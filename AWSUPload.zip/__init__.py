# -*- coding: utf-8 -*-

__author__ = 'Ardy Dedase'
__email__ = 'ardy.dedase@gmail.com'
__version__ = '0.1.2'

from .amadeus import Flights, Hotels, Cars, CO2Emissions, RailStations, Trains
